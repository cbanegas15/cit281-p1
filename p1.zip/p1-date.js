/*
    CIT 281 Project 1
    Name: Christian Banegas
*/

const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const currentDay = new Date().getDay();
console.log(daysOfWeek[currentDay]);

