/*
    CIT 281 Project 1
    Name: Christian Banegas
*/

// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

function getRandomLowercaseLetter() {
    return String.fromCharCode(getRandomInteger(97, 123));
}

function getRandomString(minLength, maxLength) {
    const length = getRandomInteger(minLength, maxLength + 1);
    let randomString = '';

    for (let i = 0; i < length; i++) {
        randomString += getRandomLowercaseLetter();
    }

    return randomString;
}

console.log(getRandomString(5, 25));
